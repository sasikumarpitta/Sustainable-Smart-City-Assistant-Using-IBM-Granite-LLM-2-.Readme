import streamlit as st
import requests

st.title("♻️ Eco Tips Generator")

keyword = st.text_input("Enter a sustainability keyword (e.g., plastic, solar):")

if st.button("Generate Tips"):
    with st.spinner("Thinking..."):
        response = requests.post(
            "http://localhost:8000/generate-tips/",
            json={"keyword": keyword}
        )
        
        st.markdown("### 🌿 Eco Tips")
        st.write(response.json())
    
        
