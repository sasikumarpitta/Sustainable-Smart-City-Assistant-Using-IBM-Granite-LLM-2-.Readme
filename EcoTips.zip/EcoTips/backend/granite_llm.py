import os,random
import httpx
from dotenv import load_dotenv
from pathlib import Path

env_path = Path(__file__).parent / ".env"
load_dotenv(dotenv_path=env_path)
API_KEY = os.getenv("WATSONX_API_KEY")
PROJECT_ID = os.getenv("WATSONX_PROJECT_ID")
BASE_URL = os.getenv("WATSONX_URL")
MODEL_ID = os.getenv("WATSONX_MODEL_ID")

async def get_ibm_iam_token(api_key: str) -> str:
    url = "https://iam.cloud.ibm.com/identity/token"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "apikey": api_key,
        "grant_type": "urn:ibm:params:oauth:grant-type:apikey"
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(url, data=data, headers=headers)
        return response.json()["access_token"]
# Authentication header


async def get_eco_tips(keyword: str) -> str:
    endpoint = f"{BASE_URL}/ml/v1/text/generation?version=2025-04-16"
    token = await get_ibm_iam_token(API_KEY)
    HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {token}",
    "ML-Instance-ID": PROJECT_ID , # <-- this is required
    "X-Global-Transaction-Id" : "111"
    
    }

    payload = {
        "version" : "2025-04-16",
        "model_id": MODEL_ID,
         "project_id": PROJECT_ID,
        "input": f"Give me practical eco-friendly tips about {keyword}",
        "parameters": {
            "decoding_method": "greedy",
            "max_new_tokens": 100
        },
       
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(endpoint, json=payload, headers=HEADERS)

    print("Status code:", response.status_code)
    print("Response text:", response.text)
    return response.json().get("generated_text", response.json()["results"][0]["generated_text"])

    try:
        return response.json().get("generated_text", "No tips generated.")
    except Exception as e:
        return f"Error parsing response: {str(e)}"
