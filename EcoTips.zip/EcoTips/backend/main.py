from fastapi import FastAPI
from pydantic import BaseModel
from granite_llm import get_eco_tips

app = FastAPI()

class TipRequest(BaseModel):
    keyword: str


@app.post("/generate-tips/")
async def generate_tips(data: TipRequest):
    try:
        tips = await get_eco_tips(data.keyword)  # ✅ keep await
        return tips
    except Exception as e:
        print(e)
        return {"tips": f"Error generating tips: {str(e)}"}
